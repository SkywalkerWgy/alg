<!-- Please use the syntax frama-c/frama-c, else it might close unrelated
     public issues
-->
Close frama-c/frama-c#NNNN

## Description

Your description here

## Companion MRs

No external plug-in impacted

<!--
- Plugin: link to MR
-->

## Tasks

- [ ] API documentation is up-to-date, or no need to update
- [ ] Manuals are up-to-date (and the CI manuals target has been run), or no
      need to update (including ACSL manual)
- [ ] Opam dependencies versions are up-to-date (and CI Opam targets have been
      run), or no changes

## Proposed Changelog Entry

<!-- Only if needed. The list of changes that warrant a Changelog entry is not completely fixed, but includes at least
  - Bug fix on pub/frama-c (use `##nnnn` to refer to the issue)
  - Modification that is visible to the end-user
  - API change, notably function deprecation

   See [Changelog](https://git.frama-c.com/frama-c/frama-c/-/blob/master/Changelog) for how to format an entry. 
-->
