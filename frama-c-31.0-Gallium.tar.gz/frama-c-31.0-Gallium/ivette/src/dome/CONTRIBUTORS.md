## Dome Contributors

(by order of appearance)

- [Loïc Correnson](loic.correnson@cea.fr), CEA-LIST, main architect
- [Franck Pujol](franck.pujol@atos.net), ATOS, early designer
- [Valentin Perrelle](valentin.perrelle@cea.fr), CEA-LIST, beta tester
- [Andre Maroneze](andre.oliveiramaroneze@cea.fr), CEA-LIST, beta tester
