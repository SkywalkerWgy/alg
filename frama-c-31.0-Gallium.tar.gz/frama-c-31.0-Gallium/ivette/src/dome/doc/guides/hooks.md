---
subtitle: Custom React Hooks
---

The **Dome** framework provides several [React Hooks](https://reactjs.org/docs/hooks-intro.html)
to ease your development process.
