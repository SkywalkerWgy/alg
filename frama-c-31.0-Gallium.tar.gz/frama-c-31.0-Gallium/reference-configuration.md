The following set of packages is known to be a working configuration for
compiling Frama-C 31.0.

- OCaml 4.14.2
- dune.3.19.1
- dune-configurator.3.19.1
- dune-site.3.19.1
- lablgtk3.3.1.5
- lablgtk3-sourceview3.3.1.5
- menhir.20240715
- ocamlfind.1.9.6
- ocamlgraph.2.2.0
- ppx_deriving_yaml.0.3.0
- ppx_deriving_yojson.3.9.0
- unionFind.20220122
- why3.1.8.0 (for wp)
- alt-ergo.2.5.4 (for wp, optional)
- yojson.2.2.2
- zarith.1.14
