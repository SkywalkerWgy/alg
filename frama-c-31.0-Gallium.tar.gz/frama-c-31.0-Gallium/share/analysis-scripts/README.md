# Analysis scripts

Documentation related to the contents of this directory is available in the
Frama-C User Manual, chapter "Analysis scripts".
